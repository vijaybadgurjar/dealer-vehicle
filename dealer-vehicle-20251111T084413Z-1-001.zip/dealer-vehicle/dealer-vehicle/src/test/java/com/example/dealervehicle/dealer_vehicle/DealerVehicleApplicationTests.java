package com.example.dealervehicle.dealer_vehicle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealerVehicleApplicationTests {

	@Test
	void contextLoads() {
	}

}
