package com.example.dealervehicle.dealer_vehicle.controller;


import com.example.dealervehicle.dealer_vehicle.dto.CreateDealerRequest;
import com.example.dealervehicle.dealer_vehicle.dto.DealerDto;
import com.example.dealervehicle.dealer_vehicle.service.DealerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dealers")
public class DealerController {

    @Autowired
    private DealerService dealerService;

    @PostMapping
    public ResponseEntity<DealerDto> create(@Valid @RequestBody CreateDealerRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(dealerService.createDealer(req));
    }

    @GetMapping("/{id}")
    public DealerDto get(@PathVariable Long id) {
        return dealerService.getDealer(id);
    }

    @GetMapping
    public List<DealerDto> list() {
        return dealerService.listDealers();
    }

    @PutMapping("/{id}")
    public DealerDto update(@PathVariable Long id, @Valid @RequestBody CreateDealerRequest req) {
        return dealerService.updateDealer(id, req);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        dealerService.deleteDealer(id);
        return ResponseEntity.noContent().build();
    }
}

