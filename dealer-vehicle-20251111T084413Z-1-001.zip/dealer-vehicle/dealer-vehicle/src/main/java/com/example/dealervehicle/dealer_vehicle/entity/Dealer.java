package com.example.dealervehicle.dealer_vehicle.entity;


import jakarta.persistence.*;
import lombok.*;



@Table(name = "dealers", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Dealer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(nullable = false)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SubscriptionType subscriptionType;

    public enum SubscriptionType {
        BASIC, PREMIUM
    }
}
