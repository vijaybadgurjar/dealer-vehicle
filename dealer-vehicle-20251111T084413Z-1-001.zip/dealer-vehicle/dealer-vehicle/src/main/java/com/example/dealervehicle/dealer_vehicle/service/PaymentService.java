package com.example.dealervehicle.dealer_vehicle.service;


import com.example.dealervehicle.dealer_vehicle.dto.PaymentRequest;
import com.example.dealervehicle.dealer_vehicle.dto.PaymentResponse;
import com.example.dealervehicle.dealer_vehicle.entity.Payment;
import com.example.dealervehicle.dealer_vehicle.repository.PaymentRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public PaymentResponse initiatePayment(PaymentRequest req) {
        Payment payment = Payment.builder()
                .dealerId(req.getDealerId())
                .amount(req.getAmount())
                .method(Payment.PaymentMethod.valueOf(req.getMethod().toUpperCase()))
                .status(Payment.PaymentStatus.PENDING)
                .build();

        paymentRepository.save(payment);
        log.info("Payment initiated for Dealer {} with amount {}", req.getDealerId(), req.getAmount());

        // simulate async callback after 5 seconds
        simulatePaymentSuccess(payment.getId());

        return PaymentResponse.builder()
                .paymentId(payment.getId())
                .dealerId(payment.getDealerId())
                .amount(payment.getAmount())
                .method(payment.getMethod().name())
                .status(payment.getStatus().name())
                .build();
    }

    @Async
    public CompletableFuture<Void> simulatePaymentSuccess(Long paymentId) {
        return CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(5000);
                Payment payment = paymentRepository.findById(paymentId).orElseThrow();
                payment.setStatus(Payment.PaymentStatus.SUCCESS);
                paymentRepository.save(payment);
                log.info("Payment ID {} marked as SUCCESS", paymentId);
            } catch (Exception e) {
                log.error("Error updating payment {}", e.getMessage());
            }
        });
    }

    public PaymentResponse getPayment(Long id) {
        Payment payment = paymentRepository.findById(id).orElseThrow();
        return PaymentResponse.builder()
                .paymentId(payment.getId())
                .dealerId(payment.getDealerId())
                .amount(payment.getAmount())
                .method(payment.getMethod().name())
                .status(payment.getStatus().name())
                .build();
    }
}
