package com.example.dealervehicle.dealer_vehicle.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentRequest {
    private Long dealerId;
    private Double amount;
    private String method; // UPI, CARD, NETBANKING
}

