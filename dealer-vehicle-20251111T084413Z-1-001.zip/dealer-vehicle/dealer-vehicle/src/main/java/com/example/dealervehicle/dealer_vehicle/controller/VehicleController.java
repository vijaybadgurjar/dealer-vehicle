package com.example.dealervehicle.dealer_vehicle.controller;



import com.example.dealervehicle.dealer_vehicle.dto.CreateVehicleRequest;
import com.example.dealervehicle.dealer_vehicle.dto.VehicleDto;
import com.example.dealervehicle.dealer_vehicle.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @PostMapping
    public ResponseEntity<VehicleDto> create(@Valid @RequestBody CreateVehicleRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(vehicleService.createVehicle(req));
    }

    @GetMapping("/{id}")
    public VehicleDto get(@PathVariable Long id) {
        return vehicleService.getVehicle(id);
    }

    @GetMapping
    public List<VehicleDto> list() {
        return vehicleService.listVehicles();
    }

    @GetMapping("/dealer/{dealerId}")
    public List<VehicleDto> listByDealer(@PathVariable Long dealerId) {
        return vehicleService.listByDealer(dealerId);
    }

    @GetMapping("/premium-dealers")
    public List<VehicleDto> listVehiclesForPremiumDealers() {
        return vehicleService.listVehiclesForPremiumDealers();
    }

    @PutMapping("/{id}")
    public VehicleDto update(@PathVariable Long id, @Valid @RequestBody CreateVehicleRequest req) {
        return vehicleService.updateVehicle(id, req);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        vehicleService.deleteVehicle(id);
        return ResponseEntity.noContent().build();
    }
}
