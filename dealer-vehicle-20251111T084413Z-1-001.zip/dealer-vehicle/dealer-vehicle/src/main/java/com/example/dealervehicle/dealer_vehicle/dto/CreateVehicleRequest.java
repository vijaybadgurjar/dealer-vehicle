package com.example.dealervehicle.dealer_vehicle.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateVehicleRequest {
    @NotBlank
    private String model;
    @NotNull
    @Min(0)
    private Double price;
    @NotBlank
    private String status;
    @NotNull
    private Long dealerId;
}
