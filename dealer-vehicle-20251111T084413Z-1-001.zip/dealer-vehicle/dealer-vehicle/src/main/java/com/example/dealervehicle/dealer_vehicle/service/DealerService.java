package com.example.dealervehicle.dealer_vehicle.service;



import com.example.dealervehicle.dealer_vehicle.dto.CreateDealerRequest;
import com.example.dealervehicle.dealer_vehicle.dto.DealerDto;
import com.example.dealervehicle.dealer_vehicle.entity.Dealer;
import com.example.dealervehicle.dealer_vehicle.exception.ResourceNotFoundException;
import com.example.dealervehicle.dealer_vehicle.mapper.MapperUtil;
import com.example.dealervehicle.dealer_vehicle.repository.DealerRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class DealerService {

    @Autowired
    private DealerRepository dealerRepository;

    public DealerDto createDealer(CreateDealerRequest req) {
        Dealer dealer = Dealer.builder()
                .name(req.getName())
                .email(req.getEmail())
                .subscriptionType(Dealer.SubscriptionType.valueOf(req.getSubscriptionType().toUpperCase()))
                .build();
        Dealer saved = dealerRepository.save(dealer);
        return MapperUtil.toDto(saved);
    }

    public DealerDto getDealer(Long id) {
        Dealer dealer = dealerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dealer", "id", id));
        return MapperUtil.toDto(dealer);
    }

    public List<DealerDto> listDealers() {
        return dealerRepository.findAll()
                .stream()
                .map(MapperUtil::toDto)
                .collect(Collectors.toList());
    }

    public DealerDto updateDealer(Long id, CreateDealerRequest req) {
        Dealer dealer = dealerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dealer", "id", id));
        dealer.setName(req.getName());
        dealer.setEmail(req.getEmail());
        dealer.setSubscriptionType(Dealer.SubscriptionType.valueOf(req.getSubscriptionType().toUpperCase()));
        Dealer updated = dealerRepository.save(dealer);
        return MapperUtil.toDto(updated);
    }

    public void deleteDealer(Long id) {
        if (!dealerRepository.existsById(id)) {
            throw new ResourceNotFoundException("Dealer", "id", id);
        }
        dealerRepository.deleteById(id);
    }
}
