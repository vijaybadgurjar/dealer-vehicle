package com.example.dealervehicle.dealer_vehicle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class DealerVehicleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DealerVehicleApplication.class, args);
	}

}
