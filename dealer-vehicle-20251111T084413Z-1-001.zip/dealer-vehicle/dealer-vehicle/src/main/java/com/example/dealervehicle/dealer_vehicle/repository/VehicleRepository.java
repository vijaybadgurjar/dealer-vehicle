package com.example.dealervehicle.dealer_vehicle.repository;

import com.example.dealervehicle.dealer_vehicle.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    List<Vehicle> findByDealerId(Long dealerId);


    @Query("SELECT v FROM Vehicle v WHERE v.dealer.subscriptionType = com.example.dealervehicle.dealer_vehicle.entity.Dealer$SubscriptionType.PREMIUM")
    List<Vehicle> findAllVehiclesByPremiumDealers();

}
