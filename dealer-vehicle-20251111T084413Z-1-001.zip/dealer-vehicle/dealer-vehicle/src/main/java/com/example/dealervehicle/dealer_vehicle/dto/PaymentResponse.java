package com.example.dealervehicle.dealer_vehicle.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentResponse {
    private Long paymentId;
    private String status;
    private Double amount;
    private String method;
    private Long dealerId;
}