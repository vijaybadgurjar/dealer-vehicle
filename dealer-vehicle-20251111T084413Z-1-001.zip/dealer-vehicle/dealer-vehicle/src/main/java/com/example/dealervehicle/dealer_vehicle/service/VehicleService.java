package com.example.dealervehicle.dealer_vehicle.service;



import com.example.dealervehicle.dealer_vehicle.dto.CreateVehicleRequest;
import com.example.dealervehicle.dealer_vehicle.dto.VehicleDto;
import com.example.dealervehicle.dealer_vehicle.entity.Dealer;
import com.example.dealervehicle.dealer_vehicle.entity.Vehicle;
import com.example.dealervehicle.dealer_vehicle.exception.ResourceNotFoundException;
import com.example.dealervehicle.dealer_vehicle.mapper.MapperUtil;
import com.example.dealervehicle.dealer_vehicle.repository.DealerRepository;
import com.example.dealervehicle.dealer_vehicle.repository.VehicleRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Transactional
@Service
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private DealerRepository dealerRepository;

    public VehicleDto createVehicle(CreateVehicleRequest req) {
        Dealer dealer = dealerRepository.findById(req.getDealerId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealer", "id", req.getDealerId()));

        Vehicle vehicle = Vehicle.builder()
                .model(req.getModel())
                .price(req.getPrice())
                .status(Vehicle.Status.valueOf(req.getStatus().toUpperCase()))
                .dealer(dealer)
                .build();

        Vehicle saved = vehicleRepository.save(vehicle);
        return MapperUtil.toDto(saved);
    }

    public VehicleDto getVehicle(Long id) {
        Vehicle v = vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle", "id", id));
        return MapperUtil.toDto(v);
    }

    public List<VehicleDto> listVehicles() {
        return vehicleRepository.findAll()
                .stream()
                .map(MapperUtil::toDto)
                .collect(Collectors.toList());
    }

    public List<VehicleDto> listByDealer(Long dealerId) {
        return vehicleRepository.findByDealerId(dealerId)
                .stream()
                .map(MapperUtil::toDto)
                .collect(Collectors.toList());
    }

    public List<VehicleDto> listVehiclesForPremiumDealers() {
        return vehicleRepository.findAllVehiclesByPremiumDealers()
                .stream()
                .map(MapperUtil::toDto)
                .collect(Collectors.toList());
    }

    public VehicleDto updateVehicle(Long id, CreateVehicleRequest req) {
        Vehicle v = vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle", "id", id));
        Dealer dealer = dealerRepository.findById(req.getDealerId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealer", "id", req.getDealerId()));

        v.setModel(req.getModel());
        v.setPrice(req.getPrice());
        v.setStatus(Vehicle.Status.valueOf(req.getStatus().toUpperCase()));
        v.setDealer(dealer);

        Vehicle updated = vehicleRepository.save(v);
        return MapperUtil.toDto(updated);
    }

    public void deleteVehicle(Long id) {
        if (!vehicleRepository.existsById(id)) {
            throw new ResourceNotFoundException("Vehicle", "id", id);
        }
        vehicleRepository.deleteById(id);
    }
}

