package com.example.dealervehicle.dealer_vehicle.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DealerDto {
    private Long id;
    private String name;
    private String email;
    private String subscriptionType;
}
