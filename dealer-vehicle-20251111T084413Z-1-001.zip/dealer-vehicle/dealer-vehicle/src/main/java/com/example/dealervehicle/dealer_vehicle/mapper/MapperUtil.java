package com.example.dealervehicle.dealer_vehicle.mapper;


import com.example.dealervehicle.dealer_vehicle.dto.DealerDto;
import com.example.dealervehicle.dealer_vehicle.dto.VehicleDto;
import com.example.dealervehicle.dealer_vehicle.entity.Dealer;
import com.example.dealervehicle.dealer_vehicle.entity.Vehicle;


public class MapperUtil {
    public static DealerDto toDto(Dealer d) {
        return DealerDto.builder()
                .id(d.getId())
                .name(d.getName())
                .email(d.getEmail())
                .subscriptionType(d.getSubscriptionType().name())
                .build();
    }

    public static VehicleDto toDto(Vehicle v) {
        return VehicleDto.builder()
                .id(v.getId())
                .model(v.getModel())
                .price(v.getPrice())
                .status(v.getStatus().name())
                .dealerId(v.getDealer().getId())
                .build();
    }
}
