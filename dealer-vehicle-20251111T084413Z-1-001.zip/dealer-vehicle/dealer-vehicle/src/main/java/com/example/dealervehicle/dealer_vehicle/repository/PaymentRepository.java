package com.example.dealervehicle.dealer_vehicle.repository;



import com.example.dealervehicle.dealer_vehicle.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
