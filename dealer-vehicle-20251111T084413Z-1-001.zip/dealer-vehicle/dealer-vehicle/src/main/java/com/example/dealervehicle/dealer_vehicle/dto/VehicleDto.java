package com.example.dealervehicle.dealer_vehicle.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class VehicleDto {
    private Long id;
    private String model;
    private Double price;
    private String status;
    private Long dealerId;
}
